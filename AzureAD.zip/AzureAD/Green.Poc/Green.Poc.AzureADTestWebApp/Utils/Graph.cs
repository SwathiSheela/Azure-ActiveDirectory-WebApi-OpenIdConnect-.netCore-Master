﻿using Microsoft.Graph;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Green.Poc.AzureADTestWebApp.Utils
{
    public class Graph
    {
        public Group Group { get; private set; } = null;

        public Graph(IGraphSdkHelper graphSdkHelper, string GroupObjId, string userId)
        {
            var graphClient = graphSdkHelper.GetAuthenticatedClient(userId);
            Group group = null;
            try
            {
                group = graphClient.Groups[GroupObjId].Request().GetAsync().Result;
            }
            catch { }
            if(group != null)
            {
                Group = group;
            }
        }
    }
}
