﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Green.Poc.AzureADTestWebApp.Models
{
    public class AzureDetails
    {
        public IEnumerable<System.Security.Claims.Claim> Claims { get; set; }
        public IEnumerable<Microsoft.Graph.Group> Groups { get; set; }
    }
}
