﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Green.Poc.AzureADTestWebApp.Extensions
{
    /// <summary>
    /// Settings relative to the AzureAD applications involved in this Web Application
    /// These are deserialized from the AzureAD section of the appsettings.json file
    /// </summary>
    public class AzureAdOptions
    {
        /// <summary>
        /// ClientId (Application Id) of this Web Application
        /// </summary>
        public string ClientId { get; set; }

        /// <summary>
        /// Client Secret (Application password) added in the Azure portal in the Keys section for the application
        /// </summary>
        public string ClientSecret { get; set; }

        /// <summary>
        /// Azure AD Cloud instance
        /// </summary>
        public string Instance { get; set; }

        /// <summary>
        ///  domain of your tenant, e.g. contoso.onmicrosoft.com
        /// </summary>
        public string Domain { get; set; }

        /// <summary>
        /// Tenant Id, as obtained from the Azure portal:
        /// (Select 'Endpoints' from the 'App registrations' blade and use the GUID in any of the URLs)
        /// </summary>
        public string TenantId { get; set; }

        /// <summary>
        /// URL on which this Web App will be called back by Azure AD (normally "/signin-oidc")
        /// </summary>
        public string CallbackPath { get; set; }

        /// <summary>
<<<<<<< HEAD
=======
        /// The base Url of this application
        /// </summary>
        public string BaseUrl { get; set; }

        /// <summary>
        /// The allowed AAD scopes
        /// </summary>
        public string Scopes { get; set; }

        /// <summary>
>>>>>>> 9e694497cd700ffbee341557d68a0b5ac2bcea4c
        /// Authority delivering the token for your tenant
        /// </summary>
        public string Authority
        {
            get
            {
<<<<<<< HEAD
                return $"{Instance}{TenantId}";
            }
        }

        /// <summary>
        /// Client Id (Application ID) of the TodoListService, obtained from the Azure portal for that application
        /// </summary>
        public string TodoListResourceId { get; set; }

        /// <summary>
        /// Base URL of the TodoListService
        /// </summary>
        public string TodoListBaseAddress { get; set; }
=======
                //return $"{Instance}/common/v2.0";
                return $"{Instance}{TenantId}";
            }
        }
        
        /// <summary>
        /// The allowed MS Graph Scopes
        /// </summary>
        public string GraphScopes { get; set; }

        /// <summary>
        /// The resource id
        /// </summary>
        public string GraphResourceId { get; set; }
>>>>>>> 9e694497cd700ffbee341557d68a0b5ac2bcea4c

        /// <summary>
        /// Instance of the settings for this Web application (to be used in controllers)
        /// </summary>
        public static AzureAdOptions Settings { set; get; }
<<<<<<< HEAD

        public string BaseUrl { get; set; }

        public string Scopes { get; set; }

        public string GraphResourceId { get; set; }

        public string GraphScopes { get; set; }
    }
}

    
=======
    }
}
>>>>>>> 9e694497cd700ffbee341557d68a0b5ac2bcea4c
