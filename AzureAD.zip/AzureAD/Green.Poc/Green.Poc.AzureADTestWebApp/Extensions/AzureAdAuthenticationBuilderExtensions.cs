<<<<<<< HEAD
﻿using Green.Poc.AzureADTestWebApp.Helpers;
using Green.Poc.AzureADTestWebApp.Utils;
=======
﻿using Green.Poc.AzureADTestWebApp.Utils;
>>>>>>> 9e694497cd700ffbee341557d68a0b5ac2bcea4c
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Microsoft.Identity.Client;
<<<<<<< HEAD
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Claims;
=======
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.IdentityModel.Tokens;
using System;
>>>>>>> 9e694497cd700ffbee341557d68a0b5ac2bcea4c
using System.Threading.Tasks;

namespace Green.Poc.AzureADTestWebApp.Extensions
{
    public static class AzureAdAuthenticationBuilderExtensions
    {
        public static AuthenticationBuilder AddAzureAd(this AuthenticationBuilder builder)
            => builder.AddAzureAd(_ => { });

        public static AuthenticationBuilder AddAzureAd(this AuthenticationBuilder builder, Action<AzureAdOptions> configureOptions)
        {
            builder.Services.Configure(configureOptions);
            builder.Services.AddSingleton<IConfigureOptions<OpenIdConnectOptions>, ConfigureAzureOptions>();
            builder.AddOpenIdConnect();
            return builder;
        }

<<<<<<< HEAD
        //private class ConfigureAzureOptions : IConfigureNamedOptions<OpenIdConnectOptions>
        //{
        //    private readonly AzureAdOptions _azureOptions;

        //    public ConfigureAzureOptions(IOptions<AzureAdOptions> azureOptions)
        //    {
        //        _azureOptions = azureOptions.Value;
        //    }

        //    public void Configure(string name, OpenIdConnectOptions options)
        //    {
        //        options.ClientId = _azureOptions.ClientId;
        //        options.Authority = _azureOptions.Authority;
        //        options.UseTokenLifetime = true;
        //        options.CallbackPath = _azureOptions.CallbackPath;
        //        options.RequireHttpsMetadata = false;
        //        options.ClientSecret = _azureOptions.ClientSecret;
        //        options.Resource = "https://graph.windows.net"; // AAD graph

        //        // Without overriding the response type (which by default is id_token), the OnAuthorizationCodeReceived event is not called.
        //        // but instead OnTokenValidated event is called. Here we request both so that OnTokenValidated is called first which 
        //        // ensures that context.Principal has a non-null value when OnAuthorizeationCodeReceived is called
        //        options.ResponseType = "id_token code";

        //        // Subscribing to the OIDC events
        //        options.Events.OnAuthorizationCodeReceived = OnAuthorizationCodeReceived;
        //        options.Events.OnAuthenticationFailed = OnAuthenticationFailed;
        //    }

        //    public void Configure(OpenIdConnectOptions options)
        //    {
        //        Configure(Options.DefaultName, options);
        //    }

        //    /// <summary>
        //    /// Redeems the authorization code by calling AcquireTokenByAuthorizationCodeAsync in order to ensure
        //    /// that the cache has a token for the signed-in user, which will then enable the controllers (like the
        //    /// TodoController, to call AcquireTokenSilentAsync successfully.
        //    /// </summary>
        //    private async Task OnAuthorizationCodeReceived(AuthorizationCodeReceivedContext context)
        //    {
        //        //var _graphClientId = "080b53c6-a7e1-4f0f-b499-e59e40b23ca8";
        //        //var _graphAuthority = "https://login.microsoftonline.com/stocktimgmail.onmicrosoft.com";
        //        //var _redirectUri = "https://localhost:44390/account/signedin";
        //        //var _graphSecret = "dosBXQE)!mqrnALE15767!|";
        //        //var _graphScopes = new string[] { "https://graph.microsoft.com/.default" };
        //        ////var _graphRequestUrl = "https://graph.microsoft.com/v1.0/users/{0}/memberOf?$select=displayName";
        //        //var _graphRequestUrl = "https://graph.windows.net/{0}/{1}?api-version={2}";

        //        // Acquire a Token for the Graph API and cache it using ADAL. In the TodoListController, we'll use the cache to acquire a token for the Todo List API
        //        string userObjectId = (context.Principal.FindFirst("http://schemas.microsoft.com/identity/claims/objectidentifier"))?.Value;
        //        var authContext = new AuthenticationContext(context.Options.Authority, new NaiveSessionCache(userObjectId, context.HttpContext.Session));
        //        var credential = new Microsoft.IdentityModel.Clients.ActiveDirectory.ClientCredential(context.Options.ClientId, context.Options.ClientSecret);

        //        var authResult = await authContext.AcquireTokenByAuthorizationCodeAsync(context.TokenEndpointRequest.Code,
        //            new Uri(context.TokenEndpointRequest.RedirectUri, UriKind.RelativeOrAbsolute), credential, context.Options.Resource);

        //        // Notify the OIDC middleware that we already took care of code redemption.
        //        context.HandleCodeRedemption(authResult.AccessToken, context.ProtocolMessage.IdToken);

        //        ////Retrieve the groups of this user through MS Graph API, since we've successfully logged in
        //        //try
        //        //{
        //        //    using (var client = new HttpClient())
        //        //    {
        //        //        var graphCred = new Microsoft.IdentityModel.Clients.ActiveDirectory.ClientCredential(_graphClientId, _graphSecret);
        //        //        var graphAuthResult = await authContext.AcquireTokenAsync("https://graph.microsoft.com/", graphCred);

        //        //        var request = new HttpRequestMessage(HttpMethod.Get, String.Format(_graphRequestUrl, AzureAdOptions.Settings.Domain, "Groups", "1.6"));
        //        //        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", graphAuthResult.AccessToken);

        //        //        var response = await client.SendAsync(request);
        //        //        var responseString = await response.Content.ReadAsStringAsync();

        //        //        var json = JObject.Parse(responseString);

        //        //        if (json["value"] != null)
        //        //        {
        //        //            var claims = new List<Claim>();
        //        //            foreach (var group in json["value"])
        //        //            {
        //        //                claims.Add(new Claim(ClaimTypes.Role, group["displayName"].ToString()));
        //        //            }

        //        //            context.Principal.AddIdentity(new ClaimsIdentity(claims));
        //        //        }
        //        //    }
        //        //}
        //        //catch (Exception e)
        //        //{

        //        //}
        //    }

        //    /// <summary>
        //    /// this method is invoked if exceptions are thrown during request processing
        //    /// </summary>
        //    private Task OnAuthenticationFailed(AuthenticationFailedContext context)
        //    {
        //        context.HandleResponse();
        //        context.Response.Redirect("/Home/Error?message=" + context.Exception.Message);
        //        return Task.FromResult(0);
        //    }
        //}


        public class ConfigureAzureOptions : IConfigureNamedOptions<OpenIdConnectOptions>
        {
            private readonly AzureAdOptions _azureOptions;

            public AzureAdOptions GetAzureAdOptions() => _azureOptions;

=======
        private class ConfigureAzureOptions : IConfigureNamedOptions<OpenIdConnectOptions>
        {
            private readonly AzureAdOptions _azureOptions;

>>>>>>> 9e694497cd700ffbee341557d68a0b5ac2bcea4c
            public ConfigureAzureOptions(IOptions<AzureAdOptions> azureOptions)
            {
                _azureOptions = azureOptions.Value;
            }

            public void Configure(string name, OpenIdConnectOptions options)
            {
                options.ClientId = _azureOptions.ClientId;
<<<<<<< HEAD
                options.Authority = $"{_azureOptions.Instance}common/v2.0";
                options.UseTokenLifetime = true;
                options.CallbackPath = _azureOptions.CallbackPath;
                options.RequireHttpsMetadata = false;
                options.ResponseType = OpenIdConnectResponseType.CodeIdToken;
                var allScopes = $"{_azureOptions.Scopes} {_azureOptions.GraphScopes}".Split(new[] { ' ' });
                foreach (var scope in allScopes) { options.Scope.Add(scope); }
=======
                options.Authority = _azureOptions.Authority;
                options.UseTokenLifetime = true;
                options.CallbackPath = _azureOptions.CallbackPath;
                options.RequireHttpsMetadata = false;
                var scopes = $"{_azureOptions.Scopes} {_azureOptions.GraphScopes}".Split(new[] { ' ' });
                foreach(var scope in scopes) { options.Scope.Add(scope); }

                // Without overriding the response type (which by default is id_token), the OnAuthorizationCodeReceived event is not called.
                // but instead OnTokenValidated event is called. Here we request both so that OnTokenValidated is called first which 
                // ensures that context.Principal has a non-null value when OnAuthorizeationCodeReceived is called
                options.ResponseType = OpenIdConnectResponseType.CodeIdToken;
>>>>>>> 9e694497cd700ffbee341557d68a0b5ac2bcea4c

                options.TokenValidationParameters = new TokenValidationParameters
                {
                    // Ensure that User.Identity.Name is set correctly after login
                    NameClaimType = "name",
<<<<<<< HEAD

                    // Instead of using the default validation (validating against a single issuer value, as we do in line of business apps),
                    // we inject our own multitenant validation logic
                    ValidateIssuer = false,

                    // If the app is meant to be accessed by entire organizations, add your issuer validation logic here.
                    //IssuerValidator = (issuer, securityToken, validationParameters) => {
                    //    if (myIssuerValidationLogic(issuer)) return issuer;
                    //}
                };

                options.Events = new OpenIdConnectEvents
                {
                    OnTicketReceived = context =>
                    {
                        // If your authentication logic is based on users then add your logic here
                        return Task.CompletedTask;
                    },
                    OnAuthenticationFailed = context =>
                    {
                        context.Response.Redirect("/Home/Error");
                        context.HandleResponse(); // Suppress the exception
                        return Task.CompletedTask;
                    },
                    OnAuthorizationCodeReceived = async (context) =>
                    {
                        var code = context.ProtocolMessage.Code;
                        var identifier = context.Principal.FindFirst(Startup.ObjectIdentifierType).Value;
                        var memoryCache = context.HttpContext.RequestServices.GetRequiredService<IMemoryCache>();
                        var graphScopes = _azureOptions.GraphScopes.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

                        var cca = new ConfidentialClientApplication(
                            _azureOptions.ClientId,
                            _azureOptions.BaseUrl + _azureOptions.CallbackPath,
                            new Microsoft.Identity.Client.ClientCredential(_azureOptions.ClientSecret),
                            new SessionTokenCache(identifier, memoryCache).GetCacheInstance(),
                            null);
                        var result = await cca.AcquireTokenByAuthorizationCodeAsync(code, graphScopes);

                        // Check whether the login is from the MSA tenant. 
                        // The sample uses this attribute to disable UI buttons for unsupported operations when the user is logged in with an MSA account.
                        var currentTenantId = context.Principal.FindFirst(Startup.TenantIdType).Value;
                        if (currentTenantId == "9188040d-6c67-4c5b-b112-36a304b66dad")
                        {
                            // MSA (Microsoft Account) is used to log in
                        }

                        context.HandleCodeRedemption(result.AccessToken, result.IdToken);
                    },
                    // If your application needs to do authenticate single users, add your user validation below.
                    //OnTokenValidated = context =>
                    //{
                    //    return myUserValidationLogic(context.Ticket.Principal);
                    //}
                };
=======
                    ValidIssuer = "https://login.microsoftonline.com/9f55e7c1-8921-40af-8d3f-fde1994d95d7/v2.0"
                };

                // Subscribing to the OIDC events
                options.Events.OnAuthorizationCodeReceived = OnAuthorizationCodeReceived;
                options.Events.OnAuthenticationFailed = OnAuthenticationFailed;
>>>>>>> 9e694497cd700ffbee341557d68a0b5ac2bcea4c
            }

            public void Configure(OpenIdConnectOptions options)
            {
                Configure(Options.DefaultName, options);
            }
<<<<<<< HEAD
        }
    }
}

=======

            /// <summary>
            /// Redeems the authorization code by calling AcquireTokenByAuthorizationCodeAsync in order to ensure
            /// that the cache has a token for the signed-in user, which will then enable the controllers (like the
            /// TodoController, to call AcquireTokenSilentAsync successfully.
            /// </summary>
            private async Task OnAuthorizationCodeReceived(AuthorizationCodeReceivedContext context)
            {
                #region Commented
                //// Acquire a Token for the Graph API and cache it using ADAL. In the TodoListController, we'll use the cache to acquire a token for the Todo List API
                //string userObjectId = (context.Principal.FindFirst("http://schemas.microsoft.com/identity/claims/objectidentifier"))?.Value;
                //var authContext = new AuthenticationContext(context.Options.Authority, new NaiveSessionCache(userObjectId, context.HttpContext.Session));
                //var credential = new Microsoft.IdentityModel.Clients.ActiveDirectory.ClientCredential(context.Options.ClientId, context.Options.ClientSecret);

                //var authResult = await authContext.AcquireTokenByAuthorizationCodeAsync(context.TokenEndpointRequest.Code,
                //    new Uri(context.TokenEndpointRequest.RedirectUri, UriKind.RelativeOrAbsolute), credential, context.Options.Resource);

                //// Notify the OIDC middleware that we already took care of code redemption.
                //context.HandleCodeRedemption(authResult.AccessToken, context.ProtocolMessage.IdToken);


                ////Retrieve the groups of this user through MS Graph API, since we've successfully logged in
                //try
                //{
                //    using (var client = new HttpClient())
                //    {
                //        var graphCred = new Microsoft.IdentityModel.Clients.ActiveDirectory.ClientCredential(_graphClientId, _graphSecret);
                //        var graphAuthResult = await authContext.AcquireTokenAsync("https://graph.microsoft.com/", graphCred);

                //        var request = new HttpRequestMessage(HttpMethod.Get, String.Format(_graphRequestUrl, AzureAdOptions.Settings.Domain, "Groups", "1.6"));
                //        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", graphAuthResult.AccessToken);

                //        var response = await client.SendAsync(request);
                //        var responseString = await response.Content.ReadAsStringAsync();

                //        var json = JObject.Parse(responseString);

                //        if (json["value"] != null)
                //        {
                //            var claims = new List<Claim>();
                //            foreach (var group in json["value"])
                //            {
                //                claims.Add(new Claim(ClaimTypes.Role, group["displayName"].ToString()));
                //            }

                //            context.Principal.AddIdentity(new ClaimsIdentity(claims));
                //        }
                //    }
                //}
                //catch (Exception e)
                //{

                //}
                #endregion
                var code = context.ProtocolMessage.Code;
                var identifier = context.Principal.FindFirst(Startup.ObjectIdentifierType).Value;
                var memoryCache = context.HttpContext.RequestServices.GetRequiredService<IMemoryCache>();
                var graphScopes = _azureOptions.GraphScopes.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

                var cca = new ConfidentialClientApplication(
                    _azureOptions.ClientId,
                    _azureOptions.Authority,
                    _azureOptions.BaseUrl + _azureOptions.CallbackPath,
                    new ClientCredential(_azureOptions.ClientSecret),
                    new SessionTokenCache(identifier, memoryCache).GetCacheInstance(),
                    null);
                var result = await cca.AcquireTokenByAuthorizationCodeAsync(code, graphScopes);
                
                context.HandleCodeRedemption(result.AccessToken, result.IdToken);
            }

            /// <summary>
            /// this method is invoked if exceptions are thrown during request processing
            /// </summary>
            private Task OnAuthenticationFailed(AuthenticationFailedContext context)
            {
                context.HandleResponse();
                context.Response.Redirect("/Home/Error?message=" + context.Exception.Message);
                return Task.FromResult(0);
            }
        }
    }
}
>>>>>>> 9e694497cd700ffbee341557d68a0b5ac2bcea4c
