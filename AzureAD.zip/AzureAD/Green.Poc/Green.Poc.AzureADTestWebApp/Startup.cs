﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Green.Poc.AzureADTestWebApp.Extensions;
<<<<<<< HEAD
=======
using Green.Poc.AzureADTestWebApp.Utils;
>>>>>>> 9e694497cd700ffbee341557d68a0b5ac2bcea4c
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Green.Poc.AzureADTestWebApp
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }
        public const string ObjectIdentifierType = "http://schemas.microsoft.com/identity/claims/objectidentifier";
<<<<<<< HEAD
        public const string TenantIdType = "http://schemas.microsoft.com/identity/claims/tenantid";

=======
>>>>>>> 9e694497cd700ffbee341557d68a0b5ac2bcea4c

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
<<<<<<< HEAD
            services.AddAuthorization(options =>
            {
                options.AddPolicy("Users",
                    policyBuilder => policyBuilder.RequireClaim("groups", 
                    Configuration.GetValue<string>("AzureSecurityGroup:UserObjectId")));
            });
=======
>>>>>>> 9e694497cd700ffbee341557d68a0b5ac2bcea4c
            services.AddAuthentication(sharedOptions =>
            {
                sharedOptions.DefaultScheme = CookieAuthenticationDefaults.AuthenticationScheme;
                sharedOptions.DefaultChallengeScheme = OpenIdConnectDefaults.AuthenticationScheme;
            })
           .AddAzureAd(options =>
           {
               Configuration.Bind("AzureAd", options);
               AzureAdOptions.Settings = options;
           })
           .AddCookie();

            services.AddMvc().AddSessionStateTempDataProvider();
            services.AddSession();

<<<<<<< HEAD
=======
            //Inject dependencies
            services.AddSingleton<IGraphAuthProvider, GraphAuthProvider>();
            services.AddTransient<IGraphSdkHelper, GraphSdkHelper>();

>>>>>>> 9e694497cd700ffbee341557d68a0b5ac2bcea4c
            services.Configure<CookiePolicyOptions>(options =>
            {
                // This lambda determines whether user consent for non-essential cookies is needed for a given request.
                options.CheckConsentNeeded = context => true;
                options.MinimumSameSitePolicy = SameSiteMode.None;
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
            }

            app.UseStaticFiles();

            app.UseSession(); // Needs to be app.UseAuthentication() and app.UseMvc() otherwise you will get an exception "Session has not been configured for this application or request."
            app.UseAuthentication();
            app.UseCookiePolicy();
            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
