﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Green.Poc.AzureADTestWebApp.Extensions;
<<<<<<< HEAD
=======
using Green.Poc.AzureADTestWebApp.Models;
>>>>>>> 9e694497cd700ffbee341557d68a0b5ac2bcea4c
using Green.Poc.AzureADTestWebApp.Utils;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
<<<<<<< HEAD
using Microsoft.AspNetCore.Mvc;
=======
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Graph;
>>>>>>> 9e694497cd700ffbee341557d68a0b5ac2bcea4c
using Microsoft.IdentityModel.Clients.ActiveDirectory;

namespace Green.Poc.AzureADTestWebApp.Controllers
{
    [Route("[controller]/[action]")]
<<<<<<< HEAD
    public class AccountController : Controller
    {
=======
    [Authorize]
    public class AccountController : Controller
    {
        private readonly IGraphSdkHelper _graphSdkHelper;

        public AccountController(IGraphSdkHelper graphSdkHelper)
        {
            _graphSdkHelper = graphSdkHelper;
        }

>>>>>>> 9e694497cd700ffbee341557d68a0b5ac2bcea4c
        [HttpGet]
        public IActionResult SignedIn()
        {
            if(User.Identity.IsAuthenticated)
            {
                return RedirectToAction("Index", "Home");
            }

            return RedirectToAction("AccessDenied");
        }

        [HttpGet]
        public IActionResult SignIn()
        {
            var redirectUrl = Url.Action(nameof(HomeController.Index), "Home");
            return Challenge(
                new AuthenticationProperties { RedirectUri = redirectUrl, AllowRefresh = true },
                OpenIdConnectDefaults.AuthenticationScheme);
        }

        [HttpGet]
<<<<<<< HEAD
        public IActionResult SignOut()
        {
            // Remove all cache entries for this user and send an OpenID Connect sign-out request.
            string userObjectID = User.FindFirst("http://schemas.microsoft.com/identity/claims/objectidentifier").Value;
            var authContext = new AuthenticationContext(AzureAdOptions.Settings.Authority,
                                                        new NaiveSessionCache(userObjectID, HttpContext.Session));
            authContext.TokenCache.Clear();

            // Let Azure AD sign-out
            var callbackUrl = Url.Action(nameof(SignedOut), "Account", values: null, protocol: Request.Scheme);
            return SignOut(
                new AuthenticationProperties { RedirectUri = callbackUrl, AllowRefresh = true },
=======
        [AllowAnonymous]
        public IActionResult SignOut()
        {
            var callbackUrl = Url.Action(nameof(SignedOut), "Account", values: null, protocol: Request.Scheme);
            return SignOut(
                new AuthenticationProperties { RedirectUri = callbackUrl },
>>>>>>> 9e694497cd700ffbee341557d68a0b5ac2bcea4c
                CookieAuthenticationDefaults.AuthenticationScheme,
                OpenIdConnectDefaults.AuthenticationScheme);
        }

        [HttpGet]
<<<<<<< HEAD
=======
        [AllowAnonymous]
>>>>>>> 9e694497cd700ffbee341557d68a0b5ac2bcea4c
        public IActionResult SignedOut()
        {
            if (User.Identity.IsAuthenticated)
            {
                // Redirect to home page if the user is authenticated.
                return RedirectToAction(nameof(HomeController.Index), "Home");
            }

            return View();
        }

        [HttpGet]
        public IActionResult AccessDenied()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Get_CurrentUserAzureADDetails()
        {
            if(User.Identity.IsAuthenticated)
            {
<<<<<<< HEAD
                return View(User.Claims);
=======
                var model = new AzureDetails
                {
                    Claims = User.Claims,
                    Groups = GetGroupData()
                };

                return View(model);
>>>>>>> 9e694497cd700ffbee341557d68a0b5ac2bcea4c
            }

            return View(null);
        }
<<<<<<< HEAD
=======

        private IEnumerable<Group> GetGroupData()
        {
            var groupObjIds = User.FindAll("groups");
            var userId = User.FindFirst(Startup.ObjectIdentifierType)?.Value;
            List<Group> groupData = new List<Group>();
            foreach(var groupId in groupObjIds)
            {
                var graph = new Graph(_graphSdkHelper, groupId.Value, userId);
                if (graph.Group != null)
                {
                    groupData.Add(graph.Group);
                }
            }
            return groupData.AsEnumerable();
        }
>>>>>>> 9e694497cd700ffbee341557d68a0b5ac2bcea4c
    }
}