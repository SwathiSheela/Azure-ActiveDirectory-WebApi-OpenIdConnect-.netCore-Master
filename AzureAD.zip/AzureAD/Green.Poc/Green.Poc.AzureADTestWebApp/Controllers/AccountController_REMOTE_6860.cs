﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Green.Poc.AzureADTestWebApp.Extensions;
using Green.Poc.AzureADTestWebApp.Models;
using Green.Poc.AzureADTestWebApp.Utils;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Graph;
using Microsoft.IdentityModel.Clients.ActiveDirectory;

namespace Green.Poc.AzureADTestWebApp.Controllers
{
    [Route("[controller]/[action]")]
    [Authorize]
    public class AccountController : Controller
    {
        private readonly IGraphSdkHelper _graphSdkHelper;

        public AccountController(IGraphSdkHelper graphSdkHelper)
        {
            _graphSdkHelper = graphSdkHelper;
        }

        [HttpGet]
        public IActionResult SignedIn()
        {
            if(User.Identity.IsAuthenticated)
            {
                return RedirectToAction("Index", "Home");
            }

            return RedirectToAction("AccessDenied");
        }

        [HttpGet]
        public IActionResult SignIn()
        {
            var redirectUrl = Url.Action(nameof(HomeController.Index), "Home");
            return Challenge(
                new AuthenticationProperties { RedirectUri = redirectUrl, AllowRefresh = true },
                OpenIdConnectDefaults.AuthenticationScheme);
        }

        [HttpGet]
        [AllowAnonymous]
        public IActionResult SignOut()
        {
            var callbackUrl = Url.Action(nameof(SignedOut), "Account", values: null, protocol: Request.Scheme);
            return SignOut(
                new AuthenticationProperties { RedirectUri = callbackUrl },
                CookieAuthenticationDefaults.AuthenticationScheme,
                OpenIdConnectDefaults.AuthenticationScheme);
        }

        [HttpGet]
        [AllowAnonymous]
        public IActionResult SignedOut()
        {
            if (User.Identity.IsAuthenticated)
            {
                // Redirect to home page if the user is authenticated.
                return RedirectToAction(nameof(HomeController.Index), "Home");
            }

            return View();
        }

        [HttpGet]
        public IActionResult AccessDenied()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Get_CurrentUserAzureADDetails()
        {
            if(User.Identity.IsAuthenticated)
            {
                var model = new AzureDetails
                {
                    Claims = User.Claims,
                    Groups = GetGroupData()
                };

                return View(model);
            }

            return View(null);
        }

        private IEnumerable<Group> GetGroupData()
        {
            var groupObjIds = User.FindAll("groups");
            var userId = User.FindFirst(Startup.ObjectIdentifierType)?.Value;
            List<Group> groupData = new List<Group>();
            foreach(var groupId in groupObjIds)
            {
                var graph = new Graph(_graphSdkHelper, groupId.Value, userId);
                if (graph.Group != null)
                {
                    groupData.Add(graph.Group);
                }
            }
            return groupData.AsEnumerable();
        }
    }
}