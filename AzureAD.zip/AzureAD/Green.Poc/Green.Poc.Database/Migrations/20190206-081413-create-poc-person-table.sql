﻿-- Migration Script

BEGIN TRANSACTION

CREATE TABLE [Poc].[Person](
   [PersonId] INT NOT NULL IDENTITY(1, 1)
  ,[FirstName] NVARCHAR(50) NULL
  ,[LastName] NVARCHAR(50) NULL
  ,[Birthday] DATE NULL
  ,[GenderId] INT NULL CONSTRAINT [FK_Person_Gender] REFERENCES [Ref].[Gender] ([GenderId])
  ,[RowVersion] TIMESTAMP NULL
  ,[Street] NVARCHAR(100) NULL
  ,[City] NVARCHAR(100) NULL
  ,[CreatedBy] NVARCHAR(256) NULL
  ,[CreatedDate] DATETIME NULL
  ,[UpdatedBy] NVARCHAR(256) NULL
  ,[UpdatedDate] DATETIME NULL
   CONSTRAINT [PK_Person] PRIMARY KEY CLUSTERED
   (
     [PersonId] ASC
   )
)
	
COMMIT TRANSACTION