﻿-- Migration Script

BEGIN TRANSACTION

-- SQL STATEMENT(s)
	CREATE TABLE [Poc].[UserAd](
   [UserAdId] INT NOT NULL IDENTITY(1, 1)
   ,[Email] NVARCHAR(150) NULL
  ,[FirstName] NVARCHAR(50) NULL
  ,[LastName] NVARCHAR(50) NULL
  ,[PassWord] NVARCHAR(50) NULL
  ,[Token] NVARCHAR(50) NULL 
  ,[RowVersion] TIMESTAMP NULL  
  ,[CreatedBy] NVARCHAR(256) NULL
  ,[CreatedDate] DATETIME NULL
  ,[UpdatedBy] NVARCHAR(256) NULL
  ,[UpdatedDate] DATETIME NULL
   CONSTRAINT [PK_UserAd] PRIMARY KEY CLUSTERED
   (
     [UserAdId] ASC
   )
)

COMMIT TRANSACTION