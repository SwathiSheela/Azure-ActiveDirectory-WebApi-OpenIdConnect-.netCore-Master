﻿using Beef.Database.Core;

namespace Green.Poc.Database
{
    class Program
    {
        static int Main(string[] args)
        {
            return DatabaseConsoleWrapper.Create("Data Source=WIN-L09GBYXNS2\\SQLSERVER2016;Initial Catalog=Green;Integrated Security=True", "Green", "Poc").Run(args);
        }
    }
}
