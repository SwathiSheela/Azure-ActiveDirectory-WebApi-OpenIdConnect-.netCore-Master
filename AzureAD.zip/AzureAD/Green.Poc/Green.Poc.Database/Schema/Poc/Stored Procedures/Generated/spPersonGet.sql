CREATE PROCEDURE [Poc].[spPersonGet]
   @PersonId AS INT
AS
BEGIN
  /*
   * This is automatically generated; any changes will be lost. 
   */
 
  SET NOCOUNT ON;

  SELECT
        [p].[PersonId]
       ,[p].[FirstName]
       ,[p].[LastName]
       ,[p].[Birthday]
       ,[p].[GenderId]
       ,[p].[RowVersion]
       ,[p].[Street]
       ,[p].[City]
       ,[p].[CreatedBy]
       ,[p].[CreatedDate]
       ,[p].[UpdatedBy]
       ,[p].[UpdatedDate]
    FROM [Poc].[Person] AS [p]
    WHERE [p].[PersonId] = @PersonId
END