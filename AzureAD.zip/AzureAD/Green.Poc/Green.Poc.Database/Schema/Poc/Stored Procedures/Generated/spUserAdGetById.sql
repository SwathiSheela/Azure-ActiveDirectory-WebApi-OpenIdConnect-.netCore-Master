CREATE PROCEDURE [Poc].[spUserAdGetById]
   @UserAdId AS INT
AS
BEGIN
  /*
   * This is automatically generated; any changes will be lost. 
   */
 
  SET NOCOUNT ON;

  SELECT
        [ua].[UserAdId]
       ,[ua].[FirstName]
       ,[ua].[LastName]
       ,[ua].[RowVersion]
       ,[ua].[CreatedBy]
       ,[ua].[CreatedDate]
       ,[ua].[UpdatedBy]
       ,[ua].[UpdatedDate]
    FROM [Poc].[UserAd] AS [ua]
    WHERE [ua].[UserAdId] = @UserAdId
END