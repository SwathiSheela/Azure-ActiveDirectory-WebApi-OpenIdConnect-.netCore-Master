CREATE PROCEDURE [Poc].[spUserAdGet]
   @UserAdId AS INT
AS
BEGIN
  /*
   * This is automatically generated; any changes will be lost. 
   */
 
  SET NOCOUNT ON;

  -- Select the requested data.
  SELECT
        [ua].[UserAdId]
       ,[ua].[Email]
       ,[ua].[FirstName]
       ,[ua].[LastName]
       ,[ua].[PassWord]
       ,[ua].[Token]
       ,[ua].[RowVersion]
       ,[ua].[CreatedBy]
       ,[ua].[CreatedDate]
       ,[ua].[UpdatedBy]
       ,[ua].[UpdatedDate]
    FROM [Poc].[UserAd] AS [ua]
    WHERE ([ua].[UserAdId] = @UserAdId)
END