﻿using Beef.CodeGen;

namespace Green.Poc.CodeGen
{
    class Program
    {
        static int Main(string[] args)
        {
            return CodeGenConsoleWrapper.Create("Green", "Poc", "WebApi").Supports(true, false, true).Run(args);
        }
    }
}
