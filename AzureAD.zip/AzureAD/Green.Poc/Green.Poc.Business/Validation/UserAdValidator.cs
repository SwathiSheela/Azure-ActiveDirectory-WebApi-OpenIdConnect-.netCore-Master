﻿using Beef.Validation;
using Green.Poc.Common.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Green.Poc.Business.Validation
{
    public class UserAdValidator : Validator<UserAd, UserAdValidator>
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PersonValidator"/>.
        /// </summary>
        public UserAdValidator()
        {
            Property(x => x.FirstName).Mandatory().Common(CommonValidators.Text);
            Property(x => x.LastName).Mandatory().Common(CommonValidators.Text);
        }
    }
}
