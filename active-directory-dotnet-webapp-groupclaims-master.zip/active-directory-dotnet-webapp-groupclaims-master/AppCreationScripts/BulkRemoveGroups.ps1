<#
 Use this script to remove the 200+ groups created in your Azure AD tenant by BulkCreateGroups.ps1
#>

$group = Get-AzureADGroup -SearchString "TestGroup001" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup002" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup003" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup004" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup005" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup006" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup007" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup008" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup009" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup010" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup011" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup012" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup013" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup014" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup015" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup016" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup017" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup018" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup019" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup020" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup021" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup022" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup023" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup024" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup025" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup026" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup027" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup028" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup029" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup030" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup031" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup032" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup033" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup034" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup035" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup036" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup037" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup038" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup039" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup040" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup041" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup042" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup043" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup044" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup045" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup046" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup047" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup048" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup049" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup050" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup051" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup052" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup053" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup054" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup055" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup056" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup057" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup058" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup059" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup060" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup061" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup062" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup063" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup064" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup065" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup066" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup067" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup068" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup069" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup070" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup071" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup072" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup073" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup074" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup075" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup076" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup077" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup078" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup079" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup080" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup081" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup082" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup083" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup084" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup085" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup086" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup087" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup088" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup089" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup090" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup091" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup092" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup093" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup094" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup095" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup096" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup097" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup098" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup099" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup100" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup101" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup102" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup103" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup104" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup105" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup106" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup107" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup108" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup109" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup110" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup111" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup112" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup113" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup114" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup115" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup116" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup117" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup118" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup119" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup120" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup121" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup122" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup123" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup124" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup125" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup126" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup127" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup128" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup129" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup130" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup131" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup132" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup133" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup134" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup135" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup136" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup137" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup138" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup139" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup140" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup141" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup142" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup143" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup144" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup145" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup146" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup147" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup148" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup149" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup150" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup151" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup152" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup153" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup154" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup155" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup156" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup157" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup158" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup159" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup160" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup161" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup162" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup163" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup164" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup165" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup166" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup167" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup168" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup169" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup170" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup171" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup172" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup173" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup174" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup175" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup176" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup177" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup178" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup179" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup180" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup181" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup182" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup183" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup184" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup185" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup186" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup187" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup188" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup189" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup190" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup191" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup192" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup193" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup194" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup195" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup196" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup197" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup198" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup199" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup200" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup201" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup202" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup203" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup204" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup205" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup206" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup207" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup208" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup209" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup210" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup211" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup212" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup213" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup214" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup215" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup216" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup217" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup218" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup219" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup220" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup221" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
$group = Get-AzureADGroup -SearchString "TestGroup222" 
Remove-AzureADGroup -ObjectId $group.ObjectId
Write-Host "Successfully deleted $($group.DisplayName)"
